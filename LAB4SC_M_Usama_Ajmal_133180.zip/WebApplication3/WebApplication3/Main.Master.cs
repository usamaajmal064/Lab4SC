﻿//Main master page so that every other web form has the same css and attributes.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication3
{
    public partial class Main : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Request.Url.ToString().IndexOf("User.aspx") > -1)
            {
                pnMenu.Visible = false;
            }
            else if (Request.Url.ToString().IndexOf("Admin.aspx") > -1)
            {
                pnMenu.Visible = false;
            }

            else if (Request.Url.ToString().IndexOf("Admin.aspx") > -1)
            {
                pnMenu.Visible = false;
            }

            else if (Request.Url.ToString().IndexOf("AdminMain.aspx") > -1)
            {
                pnMenu.Visible = false;
            }

            else
                pnMenu.Visible = true;
        }
    }
}