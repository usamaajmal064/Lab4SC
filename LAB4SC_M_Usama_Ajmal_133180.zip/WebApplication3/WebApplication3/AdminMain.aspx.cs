﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication3
{
    public partial class AdminMain : System.Web.UI.Page
    {
        OleDbConnection con = new OleDbConnection(ConfigurationManager.AppSettings["Conn"]);
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["Username"] != null)
            {
                Label1.Text = Session["Username"].ToString();
            }
            else
            {
                Response.Redirect("Admin.aspx");
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session.RemoveAll();
            Response.Redirect("Default.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            con.Open();
            
            string selectString = "SELECT * FROM [User]";

            
            OleDbCommand cmd = new OleDbCommand(selectString, con);

    
            OleDbDataReader reader = cmd.ExecuteReader();

            
            DisplayTable.Width = Unit.Percentage(90.00);
            
            TableRow tableHeading = new TableRow();

            
            TableHeaderCell Username = new TableHeaderCell();
            Username.Text = "Name";
            Username.HorizontalAlign = HorizontalAlign.Left;
            tableHeading.Cells.Add(Username);

            //Create and add the cells that contain the Contact Name column heading text.
            TableHeaderCell Discipline = new TableHeaderCell();
            Discipline.Text = "Discipline";
            Discipline.HorizontalAlign = HorizontalAlign.Left;
            tableHeading.Cells.Add(Discipline);

            //Create and add the cells that contain the Phone column heading text.
            TableHeaderCell ContactNum = new TableHeaderCell();
            ContactNum.Text = "Contact";
            ContactNum.HorizontalAlign = HorizontalAlign.Left;
            tableHeading.Cells.Add(ContactNum);

            //Create and add the cells that contain the Phone column heading text.
            TableHeaderCell FavouriteSport = new TableHeaderCell();
            FavouriteSport.Text = "FavouriteSport";
            FavouriteSport.HorizontalAlign = HorizontalAlign.Left;
            tableHeading.Cells.Add(FavouriteSport);

            //Create and add the cells that contain the Phone column heading text.
            TableHeaderCell Major = new TableHeaderCell();
            Major.Text = "Major";
            Major.HorizontalAlign = HorizontalAlign.Left;
            tableHeading.Cells.Add(Major);

            //Create and add the cells that contain the Phone column heading text.
            TableHeaderCell Batch = new TableHeaderCell();
            Batch.Text = "Batch";
            Batch.HorizontalAlign = HorizontalAlign.Left;
            tableHeading.Cells.Add(Batch);


            DisplayTable.Rows.Add(tableHeading);

            //Loop through the resultant data selection and add the data value
            //for each respective column in the table.
            while (reader.Read())
            {
                TableRow detailsRow = new TableRow();
                TableCell customerIDCell = new TableCell();
                customerIDCell.Text = reader["Name"].ToString();
                detailsRow.Cells.Add(customerIDCell);

                TableCell contactNameCell = new TableCell();
                contactNameCell.Text = reader["Discipline"].ToString();
                detailsRow.Cells.Add(contactNameCell);

                TableCell phoneCell = new TableCell();
                phoneCell.Text = reader["Telno"].ToString();
                detailsRow.Cells.Add(phoneCell);

                TableCell FavSport = new TableCell();
                FavSport.Text = reader["FavouriteSport"].ToString();
                detailsRow.Cells.Add(FavSport);

                TableCell Maj = new TableCell();
                Maj.Text = reader["Major"].ToString();
                detailsRow.Cells.Add(Maj);

                TableCell Batc = new TableCell();
                Batc.Text = reader["Batch"].ToString();
                detailsRow.Cells.Add(Batc);

                DisplayTable.Rows.Add(detailsRow);

            }

            //Close the reader and the related connection.
            reader.Close();
            con.Close();
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection(ConfigurationManager.AppSettings["Conn"]);
            con.Open();

            OleDbCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;


            cmd.CommandText = "delete from [User] where [Name]='" + TextBox1.Text + "'";

            cmd.ExecuteNonQuery();

            con.Close();
            Label2.Text="User Deleted !!";
        }
    }
}