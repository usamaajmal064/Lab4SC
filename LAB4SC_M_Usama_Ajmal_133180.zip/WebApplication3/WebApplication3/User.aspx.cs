﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication3
{
    public partial class User : System.Web.UI.Page
    {
        OleDbConnection con = new OleDbConnection(ConfigurationManager.AppSettings["Conn"]);
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            con.Open();

            OleDbCommand cmd = new OleDbCommand();


            cmd.CommandText = "insert into [User]([Name],[Discipline],[Telno],[FavouriteSport],[Major],[Batch])values(@name,@dis,@tel,@fav,@maj,@batch)";
            cmd.Parameters.AddWithValue("@name", TextBox1.Text);


            cmd.Parameters.AddWithValue("@dis", TextBox2.Text);

            cmd.Parameters.AddWithValue("@tel", TextBox3.Text);

            cmd.Parameters.AddWithValue("@fav", TextBox4.Text);

            cmd.Parameters.AddWithValue("@maj", TextBox5.Text);

            cmd.Parameters.AddWithValue("@batch", TextBox6.Text);


            cmd.Connection = con;

            OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM [User] where [Name]='" + TextBox1.Text + "'", con);
            DataTable dt = new DataTable();

            da.Fill(dt);

            if (dt.Rows.Count >= 1)
            {
                Label1.Text = "User Information Already exists !!";
            }

            int a = cmd.ExecuteNonQuery();

            if (dt.Rows.Count <= 0)
            {
                if (a > 0)
                {
                    Label1.Text = "User Information Recorded!!";

                }
            }
        }
    }
}