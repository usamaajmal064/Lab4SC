﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication3
{
    public partial class Admin : System.Web.UI.Page
    {
        OleDbConnection con = new OleDbConnection(ConfigurationManager.AppSettings["Conn"]);
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            OleDbDataAdapter da = new OleDbDataAdapter("SELECT * FROM [Admin] where [Username]='" + TextBox1.Text + "' and [Password]='" + TextBox2.Text + "'", con);

            DataTable dt = new DataTable();

            da.Fill(dt);

            if (dt.Rows.Count <= 0)
            {
                Label1.Text = "Username or Password is Invalid. Try again !!";

            }

            else
            {
                Session["Username"] = TextBox1.Text;
                Response.Redirect("AdminMain.aspx");

            }
        }
    }
}